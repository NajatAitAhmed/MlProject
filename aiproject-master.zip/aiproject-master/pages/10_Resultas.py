import streamlit as st

st.title("Résultats obtenus grâce à l'analyse qualitative-quantitative bivariée")
st.write("**1)** L'hypertension touche les personnes dont l'âge appartient à [60,80] ans.")
st.write("**2)** Les personnes âgées de 65 à 80 ans sont principalement touchées par les maladies cardiaques.")
st.write("**3)** Les personnes travaillant en tant que travailleurs indépendants ont généralement entre 57 et 77 ans")
st.write("**4)** les personnes mariées sont entre 50 et 77 ans")
st.write("**5)** La bmi est élevée pour les personnes mariées, self-employed et private (>25 kg/m²)")