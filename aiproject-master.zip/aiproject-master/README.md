# StrokeAiProject
